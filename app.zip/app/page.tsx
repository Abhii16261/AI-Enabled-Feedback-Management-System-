import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Header from "@/components/header"
import VoiceAssistant from "@/components/voice-assistant"
import { MessageSquare, Search, Phone, Zap, CreditCard, FileText, Users } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">North Bihar Power Distribution Company Limited</h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">Serving Bihar with Reliable Power Distribution</p>
          <p className="text-lg mb-8 max-w-4xl mx-auto">
            NBPDCL is committed to providing quality electricity services to the people of North Bihar. Submit your
            feedback, complaints, or suggestions to help us serve you better.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/feedback">
              <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
                <MessageSquare className="mr-2 h-5 w-5" />
                Submit Feedback
              </Button>
            </Link>
            <Link href="/track">
              <Button
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-blue-600"
              >
                <Search className="mr-2 h-5 w-5" />
                Track Complaint
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Our Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader className="text-center">
                <Zap className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                <CardTitle>New Connection</CardTitle>
                <CardDescription>Apply for new electricity connection</CardDescription>
              </CardHeader>
              <CardContent>
                <Button className="w-full" variant="outline">
                  Learn More
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader className="text-center">
                <CreditCard className="h-12 w-12 text-green-600 mx-auto mb-4" />
                <CardTitle>Bill Payment</CardTitle>
                <CardDescription>Pay your electricity bills online</CardDescription>
              </CardHeader>
              <CardContent>
                <Button className="w-full" variant="outline">
                  Pay Now
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader className="text-center">
                <FileText className="h-12 w-12 text-orange-600 mx-auto mb-4" />
                <CardTitle>Report Outage</CardTitle>
                <CardDescription>Report power outages in your area</CardDescription>
              </CardHeader>
              <CardContent>
                <Button className="w-full" variant="outline">
                  Report Now
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader className="text-center">
                <Users className="h-12 w-12 text-purple-600 mx-auto mb-4" />
                <CardTitle>Customer Care</CardTitle>
                <CardDescription>24/7 customer support service</CardDescription>
              </CardHeader>
              <CardContent>
                <Button className="w-full" variant="outline">
                  Contact Us
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Emergency Contact */}
      <section className="bg-red-50 py-12">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center mb-4">
            <Phone className="h-8 w-8 text-red-600 mr-3" />
            <h2 className="text-2xl font-bold text-red-600">Emergency Contact</h2>
          </div>
          <p className="text-lg mb-4">For power emergencies and urgent issues</p>
          <div className="text-3xl font-bold text-red-600 mb-4">1912</div>
          <p className="text-gray-600">Available 24/7 for emergency assistance</p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">NBPDCL</h3>
              <p className="text-gray-300">
                North Bihar Power Distribution Company Limited - Committed to reliable power distribution.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2 text-gray-300">
                <li>
                  <Link href="/feedback" className="hover:text-white">
                    Submit Feedback
                  </Link>
                </li>
                <li>
                  <Link href="/track" className="hover:text-white">
                    Track Complaint
                  </Link>
                </li>
                <li>
                  <Link href="/services" className="hover:text-white">
                    Services
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-white">
                    Contact Us
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Services</h3>
              <ul className="space-y-2 text-gray-300">
                <li>New Connection</li>
                <li>Bill Payment</li>
                <li>Outage Reporting</li>
                <li>Customer Support</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Contact Info</h3>
              <div className="space-y-2 text-gray-300">
                <p>Emergency: 1912</p>
                <p>Email: support@nbpdcl.gov.in</p>
                <p>Address: Patna, Bihar</p>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-300">
            <p>&copy; 2024 North Bihar Power Distribution Company Limited. All rights reserved.</p>
          </div>
        </div>
      </footer>

      <VoiceAssistant />
    </div>
  )
}
