"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Header from "@/components/header"
import { useLanguage } from "@/components/language-provider"
import {
  TrendingUp,
  TrendingDown,
  Clock,
  CheckCircle,
  AlertCircle,
  FileText,
  Download,
  BarChart3,
  PieChart,
  Calendar,
  Filter,
} from "lucide-react"

export default function DashboardPage() {
  const [hoveredSegment, setHoveredSegment] = useState<number | null>(null)
  const [selectedTimeRange, setSelectedTimeRange] = useState("7d")

  const [stats, setStats] = useState({
    totalFeedback: 324,
    resolvedFeedback: 261,
    pendingFeedback: 63,
    highPriority: 28,
    avgResolutionTime: 25.4,
    satisfactionRate: 87.5,
  })

  const [recentFeedback, setRecentFeedback] = useState([
    {
      id: "NBPDCL-2024-001",
      title: "Power outage in Muzaffarpur",
      category: "Power Outage",
      priority: "high",
      status: "pending",
      createdAt: "2024-01-15T10:30:00Z",
      aiSentiment: "negative",
      aiSummary: "Customer reporting frequent power cuts affecting daily activities",
      location: "Muzaffarpur, Bihar",
    },
    {
      id: "NBPDCL-2024-002",
      title: "High electricity bill query",
      category: "Billing",
      priority: "medium",
      status: "resolved",
      createdAt: "2024-01-14T14:20:00Z",
      aiSentiment: "neutral",
      aiSummary: "Customer inquiry about increased bill amount, resolved with explanation",
      location: "Patna, Bihar",
    },
    {
      id: "NBPDCL-2024-003",
      title: "New connection request",
      category: "New Connection",
      priority: "low",
      status: "in_progress",
      createdAt: "2024-01-14T09:15:00Z",
      aiSentiment: "positive",
      aiSummary: "Customer requesting new connection for residential property",
      location: "Darbhanga, Bihar",
    },
  ])

  const { t } = useLanguage()

  const weeklyData = [
    { day: "Mon", feedback: 45, resolved: 38, date: "Jan 8" },
    { day: "Tue", feedback: 52, resolved: 41, date: "Jan 9" },
    { day: "Wed", feedback: 38, resolved: 35, date: "Jan 10" },
    { day: "Thu", feedback: 61, resolved: 48, date: "Jan 11" },
    { day: "Fri", feedback: 43, resolved: 39, date: "Jan 12" },
    { day: "Sat", feedback: 56, resolved: 42, date: "Jan 13" },
    { day: "Sun", feedback: 29, resolved: 18, date: "Jan 14" },
  ]

  const categoryData = [
    { name: "Power Outage", value: 35, color: "#e11d48", count: 113 },
    { name: "Billing Issues", value: 25, color: "#f59e0b", count: 81 },
    { name: "New Connection", value: 20, color: "#10b981", count: 65 },
    { name: "Meter Issues", value: 12, color: "#3b82f6", count: 39 },
    { name: "Others", value: 8, color: "#8b5cf6", count: 26 },
  ]

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "resolved":
        return "bg-green-100 text-green-800"
      case "pending":
        return "bg-red-100 text-red-800"
      case "in_progress":
        return "bg-blue-100 text-blue-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case "positive":
        return "text-green-600"
      case "negative":
        return "text-red-600"
      case "neutral":
        return "text-gray-600"
      default:
        return "text-gray-600"
    }
  }

  // Calculate cumulative angles for pie chart
  const getSegmentPath = (startAngle: number, endAngle: number, radius = 90) => {
    const centerX = 96
    const centerY = 96
    const startAngleRad = (startAngle * Math.PI) / 180
    const endAngleRad = (endAngle * Math.PI) / 180

    const x1 = centerX + radius * Math.cos(startAngleRad)
    const y1 = centerY + radius * Math.sin(startAngleRad)
    const x2 = centerX + radius * Math.cos(endAngleRad)
    const y2 = centerY + radius * Math.sin(endAngleRad)

    const largeArcFlag = endAngle - startAngle <= 180 ? "0" : "1"

    return `M ${centerX} ${centerY} L ${x1} ${y1} A ${radius} ${radius} 0 ${largeArcFlag} 1 ${x2} ${y2} Z`
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <div className="container mx-auto px-4 py-8">
        {/* Header Section */}
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-6 space-y-4 lg:space-y-0">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{t("dashboard.title")}</h1>
            <p className="text-gray-600 text-sm">Monitor and analyze customer feedback</p>
          </div>
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-2 bg-white rounded-md border px-3 py-1.5">
              <Calendar className="h-4 w-4 text-gray-500" />
              <select
                value={selectedTimeRange}
                onChange={(e) => setSelectedTimeRange(e.target.value)}
                className="text-sm border-none outline-none bg-transparent"
              >
                <option value="7d">Last 7 days</option>
                <option value="30d">Last 30 days</option>
                <option value="90d">Last 3 months</option>
              </select>
            </div>
            <Button variant="outline" size="sm">
              <Filter className="h-4 w-4 mr-2" />
              Filter
            </Button>
            <Button size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{t("dashboard.total_feedback")}</CardTitle>
              <FileText className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalFeedback}</div>
              <p className="text-xs text-muted-foreground flex items-center mt-1">
                <TrendingUp className="h-3 w-3 mr-1 text-green-600" />
                +12% from last month
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{t("dashboard.resolved")}</CardTitle>
              <CheckCircle className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.resolvedFeedback}</div>
              <p className="text-xs text-muted-foreground flex items-center mt-1">
                <TrendingUp className="h-3 w-3 mr-1 text-green-600" />
                +8% from last month
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{t("dashboard.pending")}</CardTitle>
              <Clock className="h-4 w-4 text-orange-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.pendingFeedback}</div>
              <p className="text-xs text-muted-foreground flex items-center mt-1">
                <TrendingDown className="h-3 w-3 mr-1 text-red-600" />
                -5% from last month
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{t("dashboard.high_priority")}</CardTitle>
              <AlertCircle className="h-4 w-4 text-red-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.highPriority}</div>
              <p className="text-xs text-muted-foreground flex items-center mt-1">
                <TrendingUp className="h-3 w-3 mr-1 text-green-600" />
                +3% from last month
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Weekly Trends Chart */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-gray-800 text-lg">
                <BarChart3 className="h-5 w-5 mr-2 text-blue-600" />
                Weekly Feedback Trends
              </CardTitle>
              <CardDescription>Feedback received vs resolved over the past week</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {weeklyData.map((day) => (
                  <div key={day.day} className="hover:bg-gray-50 p-2 rounded-md">
                    <div className="flex items-center space-x-4">
                      <div className="w-16 text-sm font-medium text-gray-700">
                        <div>{day.day}</div>
                        <div className="text-xs text-gray-500">{day.date}</div>
                      </div>
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                            <span className="text-sm text-gray-600">Received</span>
                          </div>
                          <span className="text-sm font-medium">{day.feedback}</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-blue-500 h-2 rounded-full"
                            style={{ width: `${(day.feedback / 70) * 100}%` }}
                          ></div>
                        </div>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                            <span className="text-sm text-gray-600">Resolved</span>
                          </div>
                          <span className="text-sm font-medium">{day.resolved}</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-green-500 h-2 rounded-full"
                            style={{ width: `${(day.resolved / 70) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Simple Pie Chart */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-gray-800 text-lg">
                <PieChart className="h-5 w-5 mr-2 text-blue-600" />
                Feedback by Category
              </CardTitle>
              <CardDescription>Distribution of feedback across different categories</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col lg:flex-row items-center space-y-6 lg:space-y-0 lg:space-x-6">
                {/* Interactive SVG Pie Chart */}
                <div className="relative">
                  <svg width="192" height="192" className="transform -rotate-90">
                    {categoryData.map((category, index) => {
                      const startAngle = categoryData.slice(0, index).reduce((sum, cat) => sum + cat.value * 3.6, 0)
                      const endAngle = startAngle + category.value * 3.6

                      return (
                        <path
                          key={category.name}
                          d={getSegmentPath(startAngle, endAngle)}
                          fill={category.color}
                          className="cursor-pointer"
                          onMouseEnter={() => setHoveredSegment(index)}
                          onMouseLeave={() => setHoveredSegment(null)}
                        />
                      )
                    })}
                    {/* Center circle */}
                    <circle cx="96" cy="96" r="35" fill="white" />
                  </svg>

                  {/* Center content */}
                  <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center">
                    {hoveredSegment !== null ? (
                      <div>
                        <div className="text-lg font-bold text-gray-800">{categoryData[hoveredSegment].value}%</div>
                        <div className="text-xs text-gray-600">{categoryData[hoveredSegment].count} items</div>
                      </div>
                    ) : (
                      <div>
                        <div className="text-lg font-bold text-gray-800">{stats.totalFeedback}</div>
                        <div className="text-xs text-gray-600">Total</div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Simple Legend */}
                <div className="space-y-2 flex-1 min-w-0">
                  {categoryData.map((category, index) => (
                    <div
                      key={category.name}
                      className="flex items-center justify-between p-2 rounded-md hover:bg-gray-50 cursor-pointer"
                      onMouseEnter={() => setHoveredSegment(index)}
                      onMouseLeave={() => setHoveredSegment(null)}
                    >
                      <div className="flex items-center space-x-3">
                        <div className="w-4 h-4 rounded-full" style={{ backgroundColor: category.color }}></div>
                        <span className="text-sm">{category.name}</span>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-medium">{category.value}%</div>
                        <div className="text-xs text-gray-500">{category.count} items</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Performance Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Resolution Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600 mb-1">
                {((stats.resolvedFeedback / stats.totalFeedback) * 100).toFixed(1)}%
              </div>
              <p className="text-sm text-gray-600 mb-2">
                {stats.resolvedFeedback} out of {stats.totalFeedback} resolved
              </p>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-blue-600 h-2 rounded-full"
                  style={{ width: `${(stats.resolvedFeedback / stats.totalFeedback) * 100}%` }}
                ></div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Avg Resolution Time</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600 mb-1">{stats.avgResolutionTime}h</div>
              <p className="text-sm text-gray-600">Average time to resolve issues</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Satisfaction Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600 mb-1">{stats.satisfactionRate}%</div>
              <p className="text-sm text-gray-600 mb-2">Customer satisfaction score</p>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-blue-600 h-2 rounded-full" style={{ width: `${stats.satisfactionRate}%` }}></div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Feedback */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">{t("dashboard.recent_feedback")}</CardTitle>
            <CardDescription>Latest feedback submissions with AI analysis</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentFeedback.map((feedback) => (
                <div key={feedback.id} className="border border-gray-200 rounded-md p-4 hover:bg-gray-50">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <h3 className="font-medium text-gray-900">{feedback.title}</h3>
                        <Badge className={getPriorityColor(feedback.priority)}>{feedback.priority}</Badge>
                        <Badge className={getStatusColor(feedback.status)}>{feedback.status.replace("_", " ")}</Badge>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mb-2">
                        <div>
                          <p className="text-sm text-gray-600">
                            <span className="font-medium">ID:</span> {feedback.id}
                          </p>
                          <p className="text-sm text-gray-600">
                            <span className="font-medium">Category:</span> {feedback.category}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">
                            <span className="font-medium">Location:</span> {feedback.location}
                          </p>
                          <p className="text-sm text-gray-600">
                            <span className="font-medium">Created:</span>{" "}
                            {new Date(feedback.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>

                      <p className="text-sm text-gray-700 mb-2 bg-gray-50 p-2 rounded-md">
                        <span className="font-medium">AI Summary:</span> {feedback.aiSummary}
                      </p>

                      <div className="flex items-center">
                        <span className={`text-sm font-medium ${getSentimentColor(feedback.aiSentiment)}`}>
                          Sentiment: {feedback.aiSentiment}
                        </span>
                      </div>
                    </div>
                    <div className="ml-4">
                      <Button variant="outline" size="sm">
                        View Details
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
