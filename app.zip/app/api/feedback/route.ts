import { type NextRequest, NextResponse } from "next/server"

// Mock database - replace with actual database connection
const feedbackData: any[] = []

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // Generate unique ticket ID
    const ticketId = `NBPDCL-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`

    // Create feedback object
    const feedback = {
      id: Date.now(),
      ticketId,
      ...body,
      status: "pending",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    // Save to mock database
    feedbackData.push(feedback)

    // Simulate AI analysis
    const aiAnalysis = await analyzeWithAI(feedback)
    feedback.aiSentiment = aiAnalysis.sentiment
    feedback.aiPriority = aiAnalysis.priority
    feedback.aiSummary = aiAnalysis.summary
    feedback.aiSuggestedAction = aiAnalysis.suggestedAction

    return NextResponse.json({
      success: true,
      ticketId: feedback.ticketId,
      message: "Feedback submitted successfully",
    })
  } catch (error) {
    console.error("Error submitting feedback:", error)
    return NextResponse.json({ success: false, message: "Failed to submit feedback" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get("status")
    const priority = searchParams.get("priority")
    const category = searchParams.get("category")

    let filteredFeedback = feedbackData

    if (status) {
      filteredFeedback = filteredFeedback.filter((f) => f.status === status)
    }
    if (priority) {
      filteredFeedback = filteredFeedback.filter((f) => f.priority === priority)
    }
    if (category) {
      filteredFeedback = filteredFeedback.filter((f) => f.category === category)
    }

    return NextResponse.json({
      success: true,
      data: filteredFeedback,
      total: filteredFeedback.length,
    })
  } catch (error) {
    console.error("Error fetching feedback:", error)
    return NextResponse.json({ success: false, message: "Failed to fetch feedback" }, { status: 500 })
  }
}

async function analyzeWithAI(feedback: any) {
  // Simulate AI analysis - replace with actual Gemini API call
  const sentiments = ["positive", "negative", "neutral"]
  const priorities = ["low", "medium", "high"]

  // Simple keyword-based analysis for demo
  const text = `${feedback.title} ${feedback.description}`.toLowerCase()

  let sentiment = "neutral"
  if (text.includes("excellent") || text.includes("good") || text.includes("satisfied")) {
    sentiment = "positive"
  } else if (text.includes("bad") || text.includes("terrible") || text.includes("outage") || text.includes("problem")) {
    sentiment = "negative"
  }

  let priority = feedback.priority
  if (text.includes("urgent") || text.includes("emergency") || text.includes("outage")) {
    priority = "high"
  }

  return {
    sentiment,
    priority,
    summary: `Customer feedback regarding ${feedback.category.toLowerCase().replace("_", " ")} - ${sentiment} sentiment detected`,
    suggestedAction:
      priority === "high"
        ? "Immediate attention required - assign to field team"
        : "Standard processing - follow up within 24 hours",
  }
}
